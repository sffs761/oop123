package com.example.demo;

import javafx.animation.AnimationTimer;
import javafx.application.Application;
import javafx.event.EventHandler;
import javafx.scene.Scene;
import javafx.scene.input.KeyCode;
import javafx.scene.input.KeyEvent;
import javafx.scene.layout.AnchorPane;
import javafx.stage.Stage;

import java.io.File;
import java.io.FileNotFoundException;

import java.util.*;

public class Main extends Application {
    public static void main(String[ ] args) {
        launch(args);
    }

    public static final int WIDTH = 20;
    public static final int HEIGHT = 15;
    public static final int SCREEN_WIDTH = 320;
    public static final int SCREEN_HEIGHT = 240;
    public static final int SCALE = 16;

    public static AnchorPane gRenderer = new AnchorPane();

    public static List<Wall> walls = new ArrayList<>();
    public static Bomber player = new Bomber();
    public static List<Enemy> enemies = new ArrayList<>();
    public static List<Brick> bricks = new ArrayList<>();
    public static List<Bomb> bombList = new ArrayList<>();
    public static ArrayList<Flame> flames = new ArrayList<>();

    public void readMap(String filePath) {
        try {
            File file = new File(filePath);
            Scanner scan = new Scanner(file);
            for (int i = 0; i < HEIGHT; i++) {
                String s = scan.nextLine();
                for (int j = 0; j < WIDTH; j++) {
                    switch (s.charAt(j)) {
                        case '#':
                            walls.add(new Wall(j * SCALE, i * SCALE));
                            break;
                        case 'p':
                            player.setX(j * SCALE);
                            player.setY(i * SCALE);
                            break;
                        case 'e':
                            Balloom e = new Balloom();
                            e.setX(j * SCALE);
                            e.setY(i * SCALE);
                            enemies.add(e);
                            break;
                        case '*':
                            bricks.add(new Brick(j * SCALE, i * SCALE));
                            break;
                        default:
                            break;
                    }
                }
            }
        } catch (FileNotFoundException e) {
            System.out.println(e.getMessage());
        }
    }

    public void render() {
        for (int i = 0; i < WIDTH; i++) {
            for (int j = 0; j < HEIGHT; j++) {
                Grass g = new Grass();
                g.setX(i * SCALE);
                g.setY(j * SCALE);
                g.render();
            }
        }
        for (Wall wall : walls) {
            wall.render();
        }
        for (Enemy enemy : enemies) {
            enemy.render();
        }
        player.render();
        for (Brick brick : bricks) {
            brick.render();
        }

    }

    AnimationTimer dead = new AnimationTimer() {
        @Override
        public void handle(long l) {
            for (Enemy enemy : enemies) {
                if (Collision.isCollision(enemy, player)) {
                    player.remove();
                }
            }
        }
    };

    AnimationTimer enemyMove = new AnimationTimer() {
        @Override
        public void handle(long l) {
            for (Enemy enemy : enemies) {
                int x = enemy.getX();
                int y = enemy.getY();
                enemy.move();

                for (Wall wall : walls) {
                    if (Collision.isCollision(enemy, wall)) {
                        enemy.setX(x);
                        enemy.setY(y);
                    }
                }
                for (Enemy otherEnemy : enemies) {
                    if (otherEnemy != enemy && Collision.isCollision(enemy, otherEnemy)) {
                        enemy.setX(x);
                        enemy.setY(y);
                    }
                }
                for (Brick brick : bricks) {
                    if (Collision.isCollision(enemy, brick)) {
                        enemy.setX(x);
                        enemy.setY(y);
                    }
                }
                for (Bomb bomb : bombList) {
                    if (Collision.isCollision(enemy, bomb)) {
                        enemy.setX(x);
                        enemy.setY(y);
                    }
                }
                enemy.update();
            }
        }
    };

    AnimationTimer play = new AnimationTimer() {
        @Override
        public void handle(long now) {
            for (Flame flame : Main.flames ) {
                for (Enemy enemy : Main.enemies) {
                    if (Collision.isCollision(flame, enemy)) {
                        enemy.dead();
                        System.out.println("collision");
                    }
                }
                if (Collision.isCollision(flame, Main.player)) {
                    System.out.println("collision");
                }
            }
        }
    };

    @Override
    public void start(Stage primaryStage) {

        primaryStage.setTitle("Bomber man");
        Scene scene = new Scene(gRenderer, SCREEN_WIDTH, SCREEN_HEIGHT);
        readMap("level1.txt");
        render();
        gRenderer.requestFocus();
        primaryStage.setScene(scene);
        primaryStage.show();

        enemyMove.start();
        //dead.start();

        gRenderer.setOnKeyPressed(new EventHandler<KeyEvent>() {
            @Override
            public void handle(KeyEvent keyEvent) {
                if (keyEvent.getCode() == KeyCode.SPACE) {
                    Bomb bomb = new Bomb();
                    double x = player.getX() % 16 < 8 ? player.getX() / 16 * 16 : (player.getX() / 16 + 1) * 16;
                    double y = player.getY() % 16 < 8 ? player.getY() / 16 * 16 : (player.getY() / 16 + 1) * 16;
                    bomb.setX((int) x);
                    bomb.setY((int) y) ;
                    bombList.add(bomb);
                    bomb.render();
                    bomb.explode();


//                    for (Enemy enemy : enemies) {
//                        if (Collision.isCollision(enemy, bomb)) {
//                            System.out.println("collision");
//                            enemy.remove();
//                        }
//                    }
                }
                int x = player.getX();
                int y = player.getY();
                player.handleEvent(keyEvent);
                for (Wall wall : walls) {
                    if (Collision.isCollision(player, wall)) {
                        player.setX(x);
                        player.setY(y);
                    }
                }
                for (Brick brick : bricks) {
                    if (Collision.isCollision(player, brick)) {
                        player.setX(x);
                        player.setY(y);
                    }
                }
//                for (Bomb bomb : bombList) {
//                    if (bomb.isWalkAble()) {
//                        if (!Collision.isCollision(player, bomb)) {
//                            bomb.setWalkAble(false);
//                        }
//                    } else {
//                        player.setX(x);
//                        player.setY(y);
//                    }
//                }
                player.update();

            }
        });

        gRenderer.setOnKeyReleased(new EventHandler<KeyEvent>() {
            @Override
            public void handle(KeyEvent keyEvent) {
                if (keyEvent.getCode() == KeyCode.UP) {
                    player.loadImage("player_up_0.png");
                } else if (keyEvent.getCode() == KeyCode.DOWN) {
                    player.loadImage("player_down_0.png");
                } else if (keyEvent.getCode() == KeyCode.LEFT) {
                    player.loadImage("player_left_0.png");
                } else if (keyEvent.getCode() == KeyCode.RIGHT) {
                    player.loadImage("player_right_0.png");
                }
                player.update();
            }
        });
    }
}