package com.example.demo;

public class Grass extends Entity {
    public Grass() {
        super();
        loadImage("grass.png");
    }
}
