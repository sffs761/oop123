package com.example.demo;

import javafx.animation.AnimationTimer;

public class Balloom extends Enemy {
    private int step = 0;

    public Balloom() {
        super();
        loadImage("balloom.png");
    }

    @Override
    public void move() {
        switch (direction) {
            case 0:
                if (frame.getY() > 0) {
                    frame.setY(frame.getY() - speed);
                }
                break;
            case 1:
                if (frame.getY() + frame.getHeight() < 240) {
                    frame.setY(frame.getY() + speed);
                }
                break;
            case 2:
                if (frame.getX() > 0) {
                    frame.setX(frame.getX() - speed);
                }
                break;
            case 3:
                if (frame.getX() + frame.getWidth() < 320) {
                    frame.setX(frame.getX() + speed);
                }
                break;
        }
        step++;
        if(step == 32) {
            direction = ((int) (Math.random() * 100) + 1) % 4;
            step = 0;
        }
    }

    public void stepDead() {
        loadImage("balloom_dead" + ((int) step / 100) + ".png");
        step++;
        update();
    }

    AnimationTimer dead = new AnimationTimer() {
        @Override
        public void handle(long now) {
            if (step < 300) {
                stepDead();
            }
            if (step == 300) {
                dead.stop();
                Main.enemies.remove(this);
                remove();
            }
        }
    };

    @Override
    public void dead() {
        step = 0;
        dead.start();
    }
}
