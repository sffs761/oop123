package com.example.demo;

import javafx.scene.input.KeyCode;
import javafx.scene.input.KeyEvent;

import java.util.ArrayList;
import java.util.List;

public class Bomber extends Entity {
    private int speed;
    private int step = 0;

    public Bomber() {
        super();
        loadImage("player.png");
        speed = 4;
    }

    public void handleEvent(KeyEvent event) {
        if (event.getCode() == KeyCode.UP) {
            if (frame.getY() > 0) {
                frame.setY(frame.getY() - speed);
            }
            loadImage("player_up_" + step + ".png");
        } else if (event.getCode() == KeyCode.DOWN) {
            if (frame.getY() + frame.getHeight() < Main.SCALE * Main.HEIGHT) {
                frame.setY(frame.getY() + speed);
            }
            loadImage("player_down_" + step + ".png");
        } else if (event.getCode() == KeyCode.LEFT) {
            if (frame.getX() > 0) {
                frame.setX(frame.getX() - speed);
            }
            loadImage("player_left_" + step + ".png");
        } else if (event.getCode() == KeyCode.RIGHT) {
            if (frame.getX() + frame.getWidth() < Main.SCALE * Main.WIDTH) {
                frame.setX(frame.getX() + speed);
            }
            loadImage("player_right_" + step + ".png");
        }
        step++;
        if (step == 4) {
            step = 0;
        }
    }

    public void dead() {

    }

    public int getSpeed() {
        return speed;
    }

    public void setSpeed(int speed) {
        this.speed = speed;
    }
}
